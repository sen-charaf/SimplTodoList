import { useState } from 'react'
import './App.css'
import SearchBar from './components/SearchBar'
import AddButton from './components/AddButton'
import ListSection from './components/ListSection'
function App() {
  const [list,setList]=useState([]);
  const [text,setText]=useState(['']);
  return (
    <>
      <SearchBar
      text={text}
      setText={setText}
      />
      <AddButton
      text={text}
      setText={setText}
      list={list}
      setList={setList}
      />
      <ListSection 
      list={list}
      setList={setList}
      />
    </>
  )
}

export default App

