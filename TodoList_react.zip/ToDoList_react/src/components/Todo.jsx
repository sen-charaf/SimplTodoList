import React from 'react'
import Content from './Content'
import DeleteButton from './DeleteButton'
import CheackBox from './CheackBox'
function Todo({iteam,list,setList}) {
  return (
    <div  className={`list-section ${iteam.cheacked ? 'iteam-cheacked' : ''}`}>
        <CheackBox 
        iteam={iteam}
        list={list}
        setList={setList}
        />
        <Content 
        text={iteam.text}
        cheackBox={iteam.cheacked}
        />
        <DeleteButton 
        iteam={iteam}
        list={list}
        setList={setList}
        />
    </div>
  )
}

export default Todo;