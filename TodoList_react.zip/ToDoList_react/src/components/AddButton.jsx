import React from 'react'

function AddButton({text,setText,list,setList}) {
  const addListHandler=() => {
    if(text!==''){
      setList(
        [...list,{text: text, id: Math.floor(Math.random()*1000), cheacked: false}]
      )
      setText('')
    }
  }

  return (
    <button className='main-add' onClick={addListHandler}>Add</button>
  )
}

export default AddButton