import React from 'react'

function DeleteButton({iteam,list,setList}) {
const deletIteamHandler = () => {
  setList(list.filter( (iteamList)  => iteamList.id!== iteam.id))
}
  return (
    <button className='mini_delete' onClick={deletIteamHandler}>delete</button>
  )
}

export default DeleteButton