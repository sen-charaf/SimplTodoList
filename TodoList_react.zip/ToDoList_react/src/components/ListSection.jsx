import React from 'react'
import Todo from './todo'
function ListSection({list,setList}) {   
  return (
    <div className="List-container">
       {list.map((iteam) => (
      <Todo key = {iteam.id+2}
      iteam={iteam}
      list={list}
      setList={setList}
      />
    ))}
    </div>
  )
}

export default ListSection