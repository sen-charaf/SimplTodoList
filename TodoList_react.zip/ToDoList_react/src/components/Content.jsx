import React from 'react'

function Content({text,cheackBox}) {
  // console.log(styleText);
    return (
    <div className={`content ${cheackBox ? 'content-cheacked' : ''}`}> {text} </div>
  )
}

export default Content