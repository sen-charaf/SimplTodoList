    import React from 'react'

function CheackBox({iteam,list,setList}) {
    const cheackHandler = () => {
        setList(list.map( iteamList => {
            if (iteamList.id === iteam.id){
                return {...iteam, cheacked: !iteam.cheacked};
            }
                return iteamList;
            })
        )
    }

    return (
    <input type="checkbox" name="todolist" id={iteam.id + 1} onClick={cheackHandler}/>
  )
}

export default CheackBox